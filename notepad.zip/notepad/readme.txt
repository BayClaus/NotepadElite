I make this app on "Windows OS"
So this app have more launcher, yeah.
but if it not work, i'm sorry bro…

IT'S MY FİRST APP. :) PLEASE BE KİND :)